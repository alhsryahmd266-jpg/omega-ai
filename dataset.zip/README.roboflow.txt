
COD mobile - v1 2025-05-14 10:27am
==============================

This dataset was exported via roboflow.com on November 12, 2026 at 7:23 PM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand and search unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

For state of the art Computer Vision training notebooks you can use with this dataset,
visit https://github.com/roboflow/notebooks

To find over 100k other datasets and pre-trained models, visit https://universe.roboflow.com

The dataset includes 493 images.
Game are annotated in YOLOv11 format.

The following pre-processing was applied to each image:

The following augmentation was applied to create 3 versions of each source image:
* Randomly crop between 0 and 31 percent of the image


